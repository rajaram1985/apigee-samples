var http = require('http');

console.log('node.js application starting...');

var svr = http.createServer(function(req, resp) {
    resp.setHeader('content-type', 'application/json');
   // resp.end('{\"Album1\": \"Rock\",\"Album2\": \"Jazz\",\"Album3\": \"Melody\",\"Album4\": \"Vintage music\",\"Album5\": \"Classic\"}');
    
    var Request = require("request");

    Request.get("http://httpbin.org/json", (error, response, body) => {
        if(error) {
            resp.end(error);
        }
        resp.end(body);
    });
});

svr.listen(9000, function() {
    console.log('Node HTTP server is listening');
});